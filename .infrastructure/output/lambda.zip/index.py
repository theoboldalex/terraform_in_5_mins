def handler(event, context):
    return {"message": "Hello World!"}

